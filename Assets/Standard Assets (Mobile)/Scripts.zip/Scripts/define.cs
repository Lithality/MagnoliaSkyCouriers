using System;
namespace define
{
public enum ClassType {Human, Elf, Fairy, Were};
public enum Speciality {Negotiation, Navigation, Combat, Magic};
public enum partsType {ManMade, Natural, Technical, Magical};
public enum Disaster :int {Dragon, ThunderStorm, Ravages, Fog, Normal};
public enum faciType {bowTurret, magiTurret, crewQuartz, stabilizer};
public enum shipType :int {Aviance, Magnolia};
}