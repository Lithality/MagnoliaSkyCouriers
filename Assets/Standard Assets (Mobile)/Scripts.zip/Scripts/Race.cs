using UnityEngine;
using System.Collections;
using define;

public abstract class Race
{
	private int Resource;
	private double panic_TH;
	private const double panic_redux = 0.1;
	protected int workSpeed;
	protected int Effeciency;
	private ClassType type;

	public Race (int resc, double panic, ClassType tp)
	{
		Resource = resc;
		panic_TH = panic;
		type = tp;

	}

	public ClassType getType()
	{
		return type;
	}

	public int getResource()
	{
		return Resource;
	}

	public double getPanicTH()
	{
		return panic_TH;
	}

	public void panicking(double rate)
	{
		panic_TH -= rate;
		if (panic_TH < 0.0) 
		{
			panic_TH = 0.0;
		}
		panicRecovery ();
	}

	private void panicRecovery()
	{
		panic_TH += panic_redux;
		if (panic_TH > 1.0)
		{
			panic_TH = 1.0;
		}
	}

	public abstract void calculateWorkEffec(partsType pt, Race r = null);
	public abstract void calculatePanic(Disaster disEvent);

}

