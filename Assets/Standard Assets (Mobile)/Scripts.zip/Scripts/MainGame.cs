﻿using UnityEngine;
using System.Collections;
using define;

public class MainGame : MonoBehaviour {

	float TotalDist = 5000;
	public float DistTravelled = 0;
	EventManager eventM;
	Ship ship;
	public GUIStyle customStyle;

	void OnGUI()
	{
		eventM.printLog (customStyle);
		GUI.Label (new Rect (Screen.width / 4, 50, 200, 200), "" + DistTravelled, customStyle);
		GUI.Label (new Rect (Screen.width / 4, 50, 200, 200), "" + DistTravelled, customStyle);
	}

	// Use this for initialization
	void Start () {
		eventM = new EventManager ();
		ship= new Ship (shipType.Aviance);
	}
	
	// Update is called once per frame
	void Update () {
	
		if (Input.GetButtonDown ("Jump")) {
			eventM.AddDebugText();
				}

		DistTravelled ++;
		eventM.UpdateEvents(DistTravelled,TotalDist);
		eventM.ManageEvents ();

	}
}
