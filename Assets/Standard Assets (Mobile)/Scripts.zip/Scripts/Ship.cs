﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using define;

//Ship class, consist of 2 child classes, facilities & Components
public class Ship {

	//Variables
	int hitPoints = 100;
	int Speed = 1;
	public List<Facility> facilities;


	public Ship(shipType type)
	{
		initializeShipFaci (type);


	}

	public void initializeShipFaci(shipType type)
	{
		switch (type) {
		case shipType.Aviance:
			facilities.Add(new Facility(faciType.bowTurret));
			facilities.Add(new Facility(faciType.magiTurret));
			facilities.Add(new Facility(faciType.stabilizer));
			facilities.Add(new Facility(faciType.crewQuartz));

			break;
		case shipType.Magnolia:
			facilities.Add(new Facility(faciType.bowTurret));
			facilities.Add(new Facility(faciType.magiTurret));
			facilities.Add(new Facility(faciType.stabilizer));
			facilities.Add(new Facility(faciType.crewQuartz));
			break;
				}

	}

	public void assignTask(Race race, Facility f)
	{
		f.Assign (race);
		Debug.Log ("Task Assigned!");
	}

	public void takeDamage(int dmg)
	{
		hitPoints -= dmg;
	}

	public void repairFacility(Facility f)
	{
		f.Repair (20);
	}

	public void Travel(int Dist)
	{
		Dist += Speed;
	}


}
