using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using define;

public class Crew : MonoBehaviour
{
	public Race leader;
	public List<Race> crews;
	public double crewMorale;

	public Crew (Race ldrChoice)
	{
		leader = ldrChoice;
		initializeCrewMembers ();

	}

	public void initializeCrewMembers()
	{
		crews [0] = new Elf ();
		crews [1] = new Fairy (leader);
		crews [2] = new Human ();
		crews [3] = new Were ();
		crews [4] = leader;
	}

	public void updateCrewWorkEffeciency(partsType part, Disaster dEvent, Race r = null)
	{
		crews [0].calculatePanic (dEvent);
		crews [0].calculateWorkEffec (part, r);
	}

	public void moraleEffects()
	{
	}
}

