﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using define;

public class EventManager {

	List <string> eventLog;
	List <Event> eventList;
	int debugCounter = 1;
	float percentDist = 0;
	// Use this for initialization
	public EventManager () {
		eventLog = new List<string> ();
		eventList = new List<Event> ();
		debugCounter = 1;
		percentDist = 0;
	}
	
	public void AddDebugText()
	{
		eventList.Add(AddEvent());
		eventLog.Add (eventList[eventList.Count - 1].getEventString(0));
		//eventLog.Add ("This is a event" + debugCounter);
		//debugCounter ++;
		}

	public Event AddEvent()
	{
		int randNum = Random.Range (0, 5);
		Debug.Log (randNum);
		Event e;
		if (randNum == 0) {
			e = new Event (Disaster.Dragon);
				} else {
			e = new Event (Disaster.Ravages);
		}
		return  e;
		}

	public void UpdateEvents(float distTravel, float totalDist)
	{
		percentDist = distTravel / totalDist * 100;
		//Debug.Log (percentDist);
		if (percentDist == 10) {
			eventList.Add(AddEvent());
			eventLog.Add (eventList[eventList.Count - 1].getEventString(0));
				}

	}

	public void ManageEvents()
	{
		if (eventList.Count > 0) {
			for (int i = 0; i < eventList.Count; i ++)
			{
				if (eventList[i].checkEventEnd() == false)
				{
					eventList[i].update();
				}
				else
				{
					eventLog.Add (eventList[eventList.Count - 1].getEventString(1));
					eventList.RemoveAt(i);

				}
			}
				}
		}


	public void printLog(GUIStyle customStyle) {
		int offset = 50;
		if (eventLog.Count > 0) {
						for (int i = 0; i < eventLog.Count; i++) {
								GUI.Label (new Rect (Screen.width / 2, i * offset, 200, 200), "" + eventLog [i], customStyle);
								
				
			}
				}
		if (eventLog.Count > 3)
		{
			eventLog.RemoveAt(0);
		}
		for (int i = 0; i < eventList.Count; i++) {
			GUI.Label (new Rect (Screen.width / 2 - 100, i * offset, 200, 200), "" + eventList[i].getEventDuration().ToString(), customStyle);
			
			
		}

	}



}
